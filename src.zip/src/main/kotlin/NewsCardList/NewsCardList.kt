package cxx.NewsCardList

import cxx.LandingPageNewsStyles
import cxx.schoolnews.newscard.NewsCard
import kotlinx.html.DIV
import kotlinx.html.div

internal fun DIV.NewsCardList() {
    div(classes = LandingPageNewsStyles.newscardlayout) {

        topnews.forEach {
            NewsCard(it.imagepath, it.newstext, it.date)
        }
    }

}

private val topnews = listOf(
    NewsUpdate(
        "/static/images/hero.png",
        "Swilla Secondary School's science team emerged victorious team at the regional science fair,showcasing innovative projects and research .. The students...",
        "Aug 12,2024"
    ),
    NewsUpdate(
        "/static/images/Photoo.png",
        "Swilla Secondary School has inaugurated a new state-of-the-art computer lab, equipped with the latest technology to enhance students’ ...",
        "may 23,2024"
    ),
    NewsUpdate(
        "/static/images/Photooo.png",
        "The annual sports day at Swilla Secondary School was a grand success, with students participating in various athletic events. The day was filled wit...",
        "jun 09 ,2024"
    ),
)

private data class NewsUpdate(
    val imagepath: String, val newstext: String, val date: String,
)
