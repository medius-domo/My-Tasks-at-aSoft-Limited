package cxx.MoreNewsUpdates

import cxx.LandingPageNewsStyles
import kotlinx.html.DIV
import kotlinx.html.a
import kotlinx.html.button
import kotlinx.html.div

internal fun DIV.Morenewsupdatebutton() {
    div(classes = LandingPageNewsStyles.morenewsupdatecontainer) {
        button(classes = LandingPageNewsStyles.MoreNewsUpdates) {
            a(href = "/news") { +"More News & Updates " }
        }

    }
}