package cxx

import io.ktor.server.routing.*

internal fun Routing.stylesheets() {
    stylesheet(FeeStructureStyles)
}