package cxx

import cxx.FeeStructureHeading.FeeStructureHeading
import cxx.FeeStructureList.FeeStructureList
import cxx.SchoolFee.FeeeStructure
import io.ktor.server.application.*
import io.ktor.server.cio.*
import io.ktor.server.engine.*
import io.ktor.server.html.*
import io.ktor.server.http.content.*
import io.ktor.server.routing.*
import kotlinx.html.*

fun main() {
    embeddedServer(CIO, 8080) {
        module()
    }.start(wait = true)
}

fun Application.module() {
    //val styles=Styles
    //val feeStructureStyles=FeeStructureStyles
    routing {
        stylesheets()
        static("/static") {
            resources("static")
        }
        get("/") {
            call.respondHtml {
                head {
                    meta { name = "viewport"; content = "width=device-width, initial-scale=1.0" }
                    title { +"task3" }
                    link(FeeStructureStyles)
                    style {
                        unsafe {
                            raw(
                                """
                @font-face {
                    font-family: "Markpro";
                    font-weight: normal;
                    src:url("/static/font/MARKPRO.OTF");
                }
                @font-face {
                    font-family: "Markpro";
                    font-weight: bold;
                    src:url("/static/font/MARKPROBOLD.OTF");
                }
                @font-face {
                    font-family: "Markpro";
                    font-weight: 900;
                    src:url("/static/font/MARKPROHEAVY.OTF");
                }
                @font-face {
                    font-family: "Markpro";
                    font-weight: 500;
                    src:url("/static/font/MARKPROMEDIUM.OTF");
                }

            """
                            )
                        }
                    }
                }
                body {
                    div (classes = FeeStructureStyles.generalwraper){
                        FeeStructureHeading()
                        FeeStructureList()
                    }
                }
            }
        }
    }
}