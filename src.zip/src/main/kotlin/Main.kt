package cxx

import cxx.MoreNewsUpdates.Morenewsupdatebutton
import cxx.NewsCardList.NewsCardList
import cxx.NewsandUpdates.NewsandUpdatesTittle
import io.ktor.server.application.*
import io.ktor.server.cio.*
import io.ktor.server.engine.*
import io.ktor.server.html.*
import io.ktor.server.http.content.*
import io.ktor.server.routing.*
import kotlinx.html.*

fun main() {
    embeddedServer(CIO, 8080) {
        module()
    }.start(wait = true)
}

fun Application.module() {
    routing {
        stylesheets()
        static("/static") {
            resources("static")
        }
        get("/") {
            call.respondHtml {
                WebsitePage {
                    title = "task2"
                    link(LandingPageNewsStyles)
                    div(classes = LandingPageNewsStyles.generaldiv) {
                        NewsandUpdatesTittle()
                        NewsCardList()
                        Morenewsupdatebutton()
                    }

                }
            }
        }
        get("/news") {
            call.respondHtml {
                WebsitePage {
                    title = "morenewspage"
                    link(NewsPageStyles)
                    h1 { +"This is more new and updates page" }
                }
            }
        }
    }
}