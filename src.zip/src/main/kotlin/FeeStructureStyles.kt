package cxx

import kotlinx.css.*
import cxx.StyleSheet as StyleSheet1

internal object FeeStructureStyles : StyleSheet1() {
    val generalwraper by classname {
        display = Display.flex
        alignItems = Align.center
        justifyContent = JustifyContent.center
        flexDirection = FlexDirection.column
    }
    val FeeStructureHeading by classname {
        color = Color("#6e1f73")
        fontFamily = "Markpro"
        fontWeight = FontWeight.w900
        media(onlyScreenMaxWidth(767.98.px)) {
            fontSize = 45.px
        }
        media(onlyScreenMinWidth(767.98.px)) {
            fontSize = 71.px
        }
    }
    val FeeStructureGeneralWraper by classname {
        display = Display.grid
        justifyContent = JustifyContent.center
        alignItems = Align.center
        gap = 1.rem
        media(onlyScreenMinWidth(767.98.px)) {
            gridTemplateColumns = GridTemplateColumns("repeat(4,1fr)")
        }

        media(onlyScreenMaxWidth(1025.px)) {
            gridTemplateColumns = GridTemplateColumns("repeat(2,1fr)")
        }
        media(onlyScreenMaxWidth(430.px)) {
            gridTemplateColumns = GridTemplateColumns("repeat(1,1fr)")
            width = 95.pct
        }
    }
    val FeeStructureWraper by classname {
        display = Display.flex
        justifyContent = JustifyContent.center
        alignItems = Align.center
    }
    val outerbox by classname {
        padding = Padding(20.px)
        borderRadius = 10.px
        border = Border(1.px, BorderStyle.solid, Color("#f0daf1"))
        textAlign = TextAlign.center
        display = Display.flex
        flexDirection = FlexDirection.column
        media(onlyScreenMinWidth(767.98.px)) {
            width = 16.5.vw
        }

        media(onlyScreenMaxWidth(1025.px)) {
            width = 34.vw
        }
        media(onlyScreenMaxWidth(430.px)) {
            width = 95.pct
        }
    }

    val heading by classname {
        color = Color("#6e1f73")
        backgroundColor = Color("#f1e9f1")
        padding = Padding(10.px)
        borderRadius = 26.px
        marginBottom = 15.px
        fontFamily = "Markpro"
        media(onlyScreenMaxWidth(430.px)) {
            fontSize = 20.px
        }
        media(onlyScreenMinWidth(431.px)) {
            fontSize = 15.px
        }
        media(onlyScreenMinWidth(767.98.px)) {
            fontSize = 20.px
        }
        media(onlyScreenMinWidth(912.px)) {
            fontSize = 20.px
        }
        media(onlyScreenMinWidth(1424.px)) {
            fontSize = 20.px
        }
    }

    val price by classname {
        display = Display.flex
        alignItems = Align.center
        gap = 2.px
    }

    val tsh by classname {
        color = Color("#888888")
        fontFamily = "Markpro"
        fontSize = 19.px
    }

    val amount by classname {
        color = Color("#121212")
        fontWeight = FontWeight.w700
        fontSize = 32.px
    }

    val yearly by classname {
        color = Color("#925796")
        fontFamily = "Markpro"
        fontSize = 20.px
        fontWeight = FontWeight.w700
    }

    val includedsection by classname {
        marginTop = 20.px
        display = Display.flex
        flexDirection = FlexDirection.column
    }

    val includedheading by classname {
        fontWeight = FontWeight.w100
        marginBottom = 10.px
        color = Color("#888888")
        fontFamily = "Markpro"
        display = Display.flex
        justifyContent = JustifyContent.flexStart
        media(onlyScreenMaxWidth(431.px)){
            fontSize=15.px
        }
        media(onlyScreenMinWidth(432.px)){
            fontSize=21.px
        }
        media(onlyScreenMinWidth(1280.px)){
            fontSize=15.px
        }

    }

    val includedlist by classname {
        listStyleType = ListStyleType.none
        padding = Padding(0.px)
        display = Display.flex
        flexDirection = FlexDirection.column
        alignItems = Align.flexStart
        fontFamily = "Markpro"
        "li" {
            margin = Margin(5.px)
            display = Display.flex
            gap = 14.px
        }
        media(onlyScreenMaxWidth(430.px)) {
            fontSize = 20.px
        }
        media(onlyScreenMinWidth(431.px)) {
            fontSize = 2.3.vw
        }
        media(onlyScreenMinWidth(767.98.px)) {
            fontSize = 11.px
        }
        media(onlyScreenMinWidth(1279.px)) {
            fontSize = 1.04.vw
        }
        media(onlyScreenMinWidth(912.px)) {
            fontSize = 2.2.vw
        }
    }

    val detailsbutton by classname {
        marginTop = 20.px
        padding = Padding(10.px)
        borderRadius = 21.px
        color = Color("#6e1f73")
        fontFamily = "Markpro"
        fontSize = 20.px
        cursor = Cursor.pointer
        fontWeight = FontWeight.w700
        border = Border(2.px, BorderStyle.solid, Color("#ebceed"))
        backgroundColor = Color.transparent
        display = Display.flex
        width = LinearDimension.fitContent

    }
    val tick by classname {
        height = 25.px
        width = 25.px
        borderRadius = 50.pct
        backgroundColor = Color("#6e1f73")
        display = Display.flex
        justifyContent = JustifyContent.center
        alignItems = Align.center
        color = Color.white
        fontSize = 16.px

    }
    val listitem by classname {
        display = Display.flex
    }
}