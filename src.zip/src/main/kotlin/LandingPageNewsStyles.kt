package cxx

import kotlinx.css.*
import kotlinx.css.properties.TextDecoration

internal object LandingPageNewsStyles : StyleSheet() {
    val body by classname {
        display = Display.flex
        justifyContent = JustifyContent.center
        alignItems = Align.center
    }

    val generaldiv by classname {
        display = Display.flex
        flexDirection = FlexDirection.column
        justifyContent = JustifyContent.center
        //width=80.pct
        alignItems = Align.center
        media(onlyScreenMaxWidth(767.98.px)) {
            width = 95.pct
        }
        media(onlyScreenMinWidth(767.98.px)) {
            width = 75.pct
        }
    }

    val wrapper by classname {
        border = Border(2.px, BorderStyle.solid, Color("#fdcad9"))
        padding = Padding(20.px)
        backgroundColor = Color.white
        borderRadius = 20.px
        display = Display.flex
        flexDirection = FlexDirection.column
        width = LinearDimension.fitContent
        justifyContent = JustifyContent.spaceBetween
        gap = 0.1.rem

    }
    val newscardlayout by classname {
        display = Display.grid
        //gridTemplateColumns=GridTemplateColumns("repeat(3,1fr)")
        gap = 1.rem
        media(onlyScreenMinWidth(767.98.px)) {
            gridTemplateColumns = GridTemplateColumns("repeat(3,1fr)")
        }
        media(onlyScreenMaxWidth(912.px)) {
            gridTemplateColumns = GridTemplateColumns("repeat(2,1fr)")
        }
        media(onlyScreenMaxWidth(430.px)) {
            gridTemplateColumns = GridTemplateColumns("repeat(1,1fr)")
        }
    }
    val imagecontainer by classname {
        textAlign = TextAlign.center
        display = Display.flex
        alignItems = Align.center
        justifyContent = JustifyContent.center
    }
    val heroimage by classname {
        display = Display.block
        borderRadius = 8.px
        objectFit = ObjectFit.cover
        width = 100.pct
    }
    val datecontainer by classname {
        paddingTop = 13.pct
    }
    val date by classname {
        color = Color("#cdccca")
        fontFamily = "markpro"
        fontSize = 17.px
    }
    val content by classname {
        color = Color("fee4e5")
        fontFamily = "markpro"
        fontSize = 20.px
    }
    val buttoncontainer by classname {
        display = Display.flex
    }
    val contentwrapper by classname {
        height = 100.pct
    }
    val readmore by classname {
        display = Display.flex
        width = LinearDimension.fitContent
        padding = Padding(13.px)
        backgroundColor = Color.white
        color = Color("#8b307f")
        border = Border(2.px, BorderStyle.solid, Color("#fdcad9"))
        borderRadius = 20.px
        fontFamily = "markpro"
        fontSize = 17.px

        "a" {
            textDecoration = TextDecoration.none
        }
    }
    val NewsandUpdates by classname {
        display = Display.flex
        justifyContent = JustifyContent.center
        color = Color("#6e1f73")
        fontFamily = "markpro"
        marginBottom = 9.px
        fontWeight = FontWeight.w900

        media(onlyScreenMaxWidth(767.98.px)) {
            fontSize = 39.px
        }
        media(onlyScreenMinWidth(767.98.px)) {
            fontSize = 70.px
        }
    }
    val morenewsupdatecontainer by classname {
        display = Display.flex
        justifyContent = JustifyContent.center
        marginTop = 37.px
    }
    val MoreNewsUpdates by classname {
        backgroundColor = Color("#6e1f73")
        display = Display.flex
        alignItems = Align.center
        justifyContent = JustifyContent.center
        border = Border(2.px, BorderStyle.solid, Color("#6e1f73"))
        borderRadius = 20.px
        "a" {
            color = Color.white
            textDecoration = TextDecoration.none
            fontFamily = "markpro"
            fontSize = 17.px
            fontWeight = FontWeight.w200
            padding = Padding(10.px)
        }
    }


}
