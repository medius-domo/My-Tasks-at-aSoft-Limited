package cxx

internal object NewsPageStyles:StyleSheet() {
}