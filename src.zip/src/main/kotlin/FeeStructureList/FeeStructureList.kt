package cxx.FeeStructureList

import cxx.FeeStructureStyles
import cxx.SchoolFee.FeeeStructure
import kotlinx.html.BODY
import kotlinx.html.DIV
import kotlinx.html.div

internal fun DIV.FeeStructureList() {
    div(classes = FeeStructureStyles.FeeStructureGeneralWraper) {
        listofFee.forEach {
            FeeeStructure(it.classlevel, it.amount)
        }
    }

}

private val listofFee = listOf(
    FeeStructure(
        "FormIV-Day Students",
        "885K"
    ),
    FeeStructure(
        "FormII-Day Students",
        "780K"
    ),
    FeeStructure(
        "FormIII-Day Students",
        "680K"
    ),
    FeeStructure(
        "FormI-Day Students",
        "680K"
    )

)

private data class FeeStructure(
    val classlevel: String, val amount: String,
)
