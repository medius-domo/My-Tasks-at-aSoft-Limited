package cxx

import kotlinx.html.*

fun HTML.WebsitePage(block: BODY.() -> Unit) {
    head {
        meta { name = "viewport"; content = "width=device-width, initial-scale=1.0" }
        link(LandingPageNewsStyles)
        style {
            unsafe {
                raw(
                    """
                @font-face {
                    font-family: "Markpro";
                    font-weight: normal;
                    src:url("/static/font/MARKPRO.OTF");
                }
                @font-face {
                    font-family: "Markpro";
                    font-weight: bold;
                    src:url("/static/font/MARKPROBOLD.OTF");
                }
                @font-face {
                    font-family: "Markpro";
                    font-weight: 900;
                    src:url("/static/font/MARKPROHEAVY.OTF");
                }
                @font-face {
                    font-family: "Markpro";
                    font-weight: 500;
                    src:url("/static/font/MARKPROMEDIUM.OTF");
                }

            """
                )
            }
        }
    }
    body(classes = LandingPageNewsStyles.body) {
        block()
    }

}