package cxx.NewsandUpdates

import cxx.LandingPageNewsStyles
import kotlinx.html.DIV
import kotlinx.html.span

internal fun DIV.NewsandUpdatesTittle() {
    span(classes = LandingPageNewsStyles.NewsandUpdates) {
        +"News & Updates"
    }
}