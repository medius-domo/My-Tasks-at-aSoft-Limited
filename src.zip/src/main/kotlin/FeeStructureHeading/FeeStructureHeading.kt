package cxx.FeeStructureHeading

import cxx.FeeStructureStyles
import kotlinx.html.DIV
import kotlinx.html.span

internal fun DIV.FeeStructureHeading(){
    span (classes = FeeStructureStyles.FeeStructureHeading ){
        +"Fee Structure"
    }
}