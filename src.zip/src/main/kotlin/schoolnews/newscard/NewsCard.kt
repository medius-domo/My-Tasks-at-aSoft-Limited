package cxx.schoolnews.newscard

import cxx.LandingPageNewsStyles
import kotlinx.html.*

internal fun DIV.NewsCard(imagepath: String, newstext: String, date: String) {
    div(classes = LandingPageNewsStyles.wrapper) {

        div(classes = LandingPageNewsStyles.imagecontainer) {
            img(src = imagepath, alt = "Hero image", classes = LandingPageNewsStyles.heroimage)
        }

        div(classes = LandingPageNewsStyles.datecontainer) {
            span(classes = LandingPageNewsStyles.date) { +date }
        }

        div(classes = LandingPageNewsStyles.contentwrapper) {
            p(classes = LandingPageNewsStyles.content) {
                +newstext
            }
        }

        div(classes = LandingPageNewsStyles.buttoncontainer) {
            button(classes = LandingPageNewsStyles.readmore) { a(href = "#") { +"Read More" } }

        }

    }
}