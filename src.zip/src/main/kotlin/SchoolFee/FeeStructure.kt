package cxx.SchoolFee

import cxx.FeeStructureStyles
import kotlinx.html.*

internal fun DIV.FeeeStructure(classlevel: String, amount: String) {
    div(classes = FeeStructureStyles.FeeStructureWraper) {
        div(classes = FeeStructureStyles.outerbox) {
            h1(classes = FeeStructureStyles.heading) {
                +classlevel
            }
            p(classes = FeeStructureStyles.price) {
                span(classes = FeeStructureStyles.tsh) { +"Tsh " }
                span(classes = FeeStructureStyles.amount) { +amount }
                span(classes = FeeStructureStyles.yearly) { +"/Yearly" }
            }
            div(classes = FeeStructureStyles.includedsection) {
                h2(classes = FeeStructureStyles.includedheading) {
                    +"What's included"
                }
                ul(classes = FeeStructureStyles.includedlist) {
                    li(classes = FeeStructureStyles.listitem)
                    {
                        div(classes = FeeStructureStyles.tick) {
                            unsafe { +"&#x2714;" }
                        }
                        +"Tuition Fee"
                    }

                    li {
                        div(classes = FeeStructureStyles.tick) {
                        unsafe { +"&#x2714;" }
                    }
                        +"Laboratory Charge"
                    }
                    li {
                        div(classes = FeeStructureStyles.tick) {
                            unsafe { +"&#x2714;" }
                        }
                        +"Examination Fee"
                    }
                    li {
                        div(classes = FeeStructureStyles.tick) {
                            unsafe { +"&#x2714;" }
                        }
                        +"Caution Fee"
                    }
                    li {
                        div(classes = FeeStructureStyles.tick) {
                            unsafe { +"&#x2714;" }
                        }
                        +"Swimming Outfits"
                    }
                    li {
                        div(classes = FeeStructureStyles.tick) {
                            unsafe { +"&#x2714;" }
                        }
                        +"ID Card"
                    }

                }
            }
            button(classes = FeeStructureStyles.detailsbutton) {
                +"More Details"
            }
        }
    }
}